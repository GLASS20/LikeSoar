package me.eldodebug.soar.mixin.mixins.block;

import me.eldodebug.soar.Soar;
import me.eldodebug.soar.management.mods.impl.ClearGlassMod;
import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
public class MixinBlockGlass extends Block {

    public MixinBlockGlass(Material blockMaterialIn, MapColor blockMapColorIn) {
        super(blockMaterialIn, blockMapColorIn);
    }

    @Override

}
